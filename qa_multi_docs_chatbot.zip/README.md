# 📚 QA Multi-Docs Assistant Chatbot

## 1. 🧪 Experimentation Phase

### a) Data Analysis & Experimentation
- Analyzed multi-format documents (PDFs, Excels) for entity and relationship extraction.
- Used Streamlit for rapid prototyping.

### b) Embedding Generation
- Models used:
  - `HuggingFaceEmbeddings` (e.g., `BAAI/bge-small-en-v1.5`)
- Text split with `RecursiveCharacterTextSplitter` for dense retrieval.

### c) Library Comparison Table
| Library                | Purpose                  | Pros                          | Cons                          |
|------------------------|---------------------------|-------------------------------|-------------------------------|
| `PyMuPDFLoader`        | PDF Parsing               | Fast, Accurate Text Extract   | Struggles with scanned PDFs   |
| `UnstructuredExcelLoader` | Excel Parsing          | Cell-level parsing            | Slightly heavy                |
| `docling` (custom)     | Semantic Triplet Parsing  | Relation-rich extraction      | Needs preprocessing support   |

---

## 2. 🚀 Implementation Phase

### a) Inference with Local LLM (Gemma 3)
Used Ollama backend to run `gemma:2b` and `llama3` locally:

```bash
ollama pull gemma:2b
```

### b) Streamlit Interface

```bash
pip install -r requirements.txt
streamlit run streamlit_kg_app.py
```

### Sample Interface
![Interface Screenshot](./assets/ui.gif)

---

## 3. 🔗 Integration Phase

### a) Hybrid RAG + KG Q&A Architecture

- `FAISS` for semantic retrieval.
- Knowledge graph built using `NetworkX` from extracted triplets.
- Integrated prompt-based QA with hybrid answers:
  - RAG-only
  - KG-only
  - Combined Answer Mode

```python
if mode == "Hybrid":
    answer_rag = qa_chain.run(question)
    answer_kg = query_kg(question)
    answer = f"🔹 RAG Answer:\n{answer_rag}\n\n🔸 KG Answer:\n{answer_kg}"
```

---

## 📦 Setup Instructions

1. Create virtual environment:

```bash
python -m venv venv
source venv/bin/activate  # on Windows: venv\Scripts\activate
```

2. Install dependencies:

```bash
pip install -r requirements.txt
```

3. Run Streamlit app:

```bash
streamlit run streamlit_kg_app.py
```

---

## 🔭 Future Roadmap

- ⏳ Session persistence and user-specific history.
- 🎯 Graph-based navigation and feedback refinement.
- 🤖 Model-based question decomposition for complex queries.

---

## 📽 Demo GIFs

| Feature           | GIF Preview            |
|------------------|------------------------|
| UI Walkthrough   | ![](./assets/ui.gif)   |
| KG Visualization | ![](./assets/kg.gif)   |

---

**Maintainer:** [@yourname] — Open for collaborations! 🚀
